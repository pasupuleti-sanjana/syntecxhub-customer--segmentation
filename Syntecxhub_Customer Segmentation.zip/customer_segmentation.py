"""
Customer Segmentation using K-Means Clustering
Syntecxhub Internship - Machine Learning Task 3, Project 1
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

# ── Styling ─────────────────────────────────────────────────────────────────
plt.rcParams.update({
    'figure.facecolor': '#F8F6FF',
    'axes.facecolor':   '#F8F6FF',
    'axes.grid': True,
    'grid.alpha': 0.3,
    'font.family': 'DejaVu Sans',
})
PALETTE = ['#5B4FCF', '#A855F7', '#06B6D4', '#F59E0B', '#EF4444']

# ── 1. CREATE DATASET ────────────────────────────────────────────────────────
np.random.seed(42)
n = 200

# Simulate realistic Mall Customers data
data = {
    'CustomerID': range(1, n+1),
    'Gender': np.random.choice(['Male', 'Female'], n, p=[0.44, 0.56]),
    'Age': np.concatenate([
        np.random.randint(18, 35, 70),
        np.random.randint(30, 55, 80),
        np.random.randint(50, 70, 50),
    ]),
    'Annual_Income_k': np.concatenate([
        np.random.randint(15, 40, 40),
        np.random.randint(40, 75, 80),
        np.random.randint(70, 137, 80),
    ]),
    'Spending_Score': np.concatenate([
        np.random.randint(60, 100, 40),   # low income high spend
        np.random.randint(40, 70,  80),   # middle
        np.random.randint(1,  50,  80),   # high income varies
    ]),
}
df = pd.DataFrame(data)

# ── 2. EDA ───────────────────────────────────────────────────────────────────
print("=" * 55)
print("  CUSTOMER SEGMENTATION — EDA SUMMARY")
print("=" * 55)
print(f"\nDataset shape: {df.shape}")
print(f"\nMissing values:\n{df.isnull().sum()}")
print(f"\nDescriptive statistics:")
print(df[['Age','Annual_Income_k','Spending_Score']].describe().round(2))
print(f"\nGender distribution:\n{df['Gender'].value_counts()}")

# ── 3. FEATURE PREP ──────────────────────────────────────────────────────────
features = ['Age', 'Annual_Income_k', 'Spending_Score']
X = df[features].copy()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ── 4. ELBOW METHOD ──────────────────────────────────────────────────────────
inertias, silhouettes = [], []
K_range = range(2, 11)
for k in K_range:
    km = KMeans(n_clusters=k, init='k-means++', n_init=10, random_state=42)
    km.fit(X_scaled)
    inertias.append(km.inertia_)
    silhouettes.append(silhouette_score(X_scaled, km.labels_))

# ── 5. APPLY K-MEANS (k=5) ───────────────────────────────────────────────────
BEST_K = 5
kmeans = KMeans(n_clusters=BEST_K, init='k-means++', n_init=20, random_state=42)
df['Cluster'] = kmeans.fit_predict(X_scaled)

sil = silhouette_score(X_scaled, df['Cluster'])
print(f"\nFinal k = {BEST_K}  |  Silhouette Score = {sil:.3f}")

# ── 6. CLUSTER PROFILING ─────────────────────────────────────────────────────
profile = df.groupby('Cluster')[features + ['Gender']].agg(
    Age_mean=('Age', 'mean'),
    Income_mean=('Annual_Income_k', 'mean'),
    Spending_mean=('Spending_Score', 'mean'),
    Count=('Age', 'count'),
)
profile = profile.round(1)

# Assign meaningful segment names based on income & spending
SEGMENT_NAMES = {
    0: 'Careful Spenders',
    1: 'High-Value Targets',
    2: 'Young Explorers',
    3: 'Budget-Conscious',
    4: 'Affluent Moderates',
}

# Auto-assign names by sorting clusters on income then spending
order = profile[['Income_mean','Spending_mean']].sort_values(
    ['Income_mean','Spending_mean']).index.tolist()
name_map = {cid: list(SEGMENT_NAMES.values())[i] for i, cid in enumerate(order)}

df['Segment'] = df['Cluster'].map(name_map)
profile['Segment'] = profile.index.map(name_map)
profile = profile.sort_values('Income_mean')

print("\n── Cluster Profile ──────────────────────────────────")
print(profile.to_string())

# ── 7. VISUALISATIONS ────────────────────────────────────────────────────────
fig = plt.figure(figsize=(20, 16))
fig.patch.set_facecolor('#F8F6FF')

# (a) Elbow + Silhouette
ax1 = fig.add_subplot(3, 3, 1)
ax1.plot(K_range, inertias, 'o-', color=PALETTE[0], lw=2, ms=7)
ax1.axvline(BEST_K, color=PALETTE[4], ls='--', alpha=0.7, label=f'k={BEST_K}')
ax1.set_title('Elbow Method', fontweight='bold')
ax1.set_xlabel('Number of Clusters (k)')
ax1.set_ylabel('Inertia')
ax1.legend()

ax2 = fig.add_subplot(3, 3, 2)
ax2.plot(K_range, silhouettes, 's-', color=PALETTE[1], lw=2, ms=7)
ax2.axvline(BEST_K, color=PALETTE[4], ls='--', alpha=0.7, label=f'k={BEST_K}')
ax2.set_title('Silhouette Scores', fontweight='bold')
ax2.set_xlabel('Number of Clusters (k)')
ax2.set_ylabel('Silhouette Score')
ax2.legend()

# (b) Income vs Spending Scatter
ax3 = fig.add_subplot(3, 3, 3)
for cid, grp in df.groupby('Cluster'):
    ax3.scatter(grp['Annual_Income_k'], grp['Spending_Score'],
                c=PALETTE[cid % len(PALETTE)], label=name_map[cid],
                alpha=0.75, edgecolors='white', s=60)
ax3.set_title('Income vs Spending Score', fontweight='bold')
ax3.set_xlabel('Annual Income (k$)')
ax3.set_ylabel('Spending Score (1–100)')
ax3.legend(fontsize=7, loc='upper left')

# (c) Age vs Spending
ax4 = fig.add_subplot(3, 3, 4)
for cid, grp in df.groupby('Cluster'):
    ax4.scatter(grp['Age'], grp['Spending_Score'],
                c=PALETTE[cid % len(PALETTE)], alpha=0.75, edgecolors='white', s=60)
ax4.set_title('Age vs Spending Score', fontweight='bold')
ax4.set_xlabel('Age')
ax4.set_ylabel('Spending Score')

# (d) Age vs Income
ax5 = fig.add_subplot(3, 3, 5)
for cid, grp in df.groupby('Cluster'):
    ax5.scatter(grp['Age'], grp['Annual_Income_k'],
                c=PALETTE[cid % len(PALETTE)], alpha=0.75, edgecolors='white', s=60)
ax5.set_title('Age vs Annual Income', fontweight='bold')
ax5.set_xlabel('Age')
ax5.set_ylabel('Annual Income (k$)')

# (e) Cluster size bar
ax6 = fig.add_subplot(3, 3, 6)
sizes = df.groupby('Cluster')['Segment'].first()
counts = df['Cluster'].value_counts().sort_index()
bars = ax6.bar([name_map[i] for i in counts.index], counts.values,
               color=PALETTE[:BEST_K], edgecolor='white', linewidth=1.2)
ax6.set_title('Cluster Sizes', fontweight='bold')
ax6.set_xlabel('Segment')
ax6.set_ylabel('Customer Count')
plt.setp(ax6.get_xticklabels(), rotation=20, ha='right', fontsize=8)
for bar, v in zip(bars, counts.values):
    ax6.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
             str(v), ha='center', va='bottom', fontsize=9, fontweight='bold')

# (f) Mean feature heatmap
ax7 = fig.add_subplot(3, 3, 7)
heat_df = profile[['Age_mean','Income_mean','Spending_mean']].copy()
heat_df.index = [name_map[i] for i in heat_df.index]
heat_df.columns = ['Avg Age','Avg Income\n(k$)','Avg Spending\nScore']
sns.heatmap(heat_df, annot=True, fmt='.1f', cmap='BuPu',
            linewidths=0.5, ax=ax7, cbar_kws={'shrink': 0.8})
ax7.set_title('Cluster Feature Heatmap', fontweight='bold')
plt.setp(ax7.get_yticklabels(), rotation=0, fontsize=8)

# (g) Gender distribution per cluster
ax8 = fig.add_subplot(3, 3, 8)
gender_counts = df.groupby(['Cluster','Gender']).size().unstack(fill_value=0)
gender_counts.index = [name_map[i] for i in gender_counts.index]
gender_counts.plot(kind='bar', ax=ax8, color=['#A855F7','#06B6D4'],
                   edgecolor='white', linewidth=1)
ax8.set_title('Gender Distribution per Segment', fontweight='bold')
ax8.set_xlabel('')
ax8.set_ylabel('Count')
plt.setp(ax8.get_xticklabels(), rotation=20, ha='right', fontsize=8)
ax8.legend(title='Gender', fontsize=8)

# (h) Box plot — spending by segment
ax9 = fig.add_subplot(3, 3, 9)
seg_order = profile['Segment'].tolist()
df_plot = df.copy()
df_plot['Segment_cat'] = pd.Categorical(df_plot['Segment'], categories=seg_order, ordered=True)
df_plot.sort_values('Segment_cat', inplace=True)
bp_data = [df_plot[df_plot['Segment'] == s]['Spending_Score'].values for s in seg_order]
bp = ax9.boxplot(bp_data, patch_artist=True, notch=False,
                 medianprops=dict(color='white', lw=2))
for patch, color in zip(bp['boxes'], PALETTE):
    patch.set_facecolor(color)
    patch.set_alpha(0.8)
ax9.set_xticklabels(seg_order, rotation=20, ha='right', fontsize=8)
ax9.set_title('Spending Score Distribution', fontweight='bold')
ax9.set_ylabel('Spending Score')

plt.suptitle('Customer Segmentation — K-Means Clustering Analysis',
             fontsize=16, fontweight='bold', y=1.01, color='#1e1b4b')
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/customer_segmentation_analysis.png',
            dpi=150, bbox_inches='tight', facecolor='#F8F6FF')
plt.close()
print("\n✓ Visualisation saved.")

# ── 8. SAVE RESULTS ──────────────────────────────────────────────────────────
df_out = df.copy()
df_out.to_csv('/mnt/user-data/outputs/customer_segments.csv', index=False)
print("✓ Cluster labels saved to customer_segments.csv")

# ── 9. SEGMENT REPORT ────────────────────────────────────────────────────────
report_lines = []
report_lines.append("=" * 60)
report_lines.append("  CUSTOMER SEGMENTATION REPORT")
report_lines.append("  Syntecxhub Internship — ML Task 3, Project 1")
report_lines.append("=" * 60)
report_lines.append(f"\nDataset  : Mall Customers (simulated, n={n})")
report_lines.append(f"Features : Age, Annual Income (k$), Spending Score")
report_lines.append(f"Algorithm: K-Means++  |  k={BEST_K}  |  Silhouette={sil:.3f}\n")

marketing_actions = {
    'Budget-Conscious':    ("Low income, low spending, older.",
                            "Value deals, loyalty rewards, discount coupons."),
    'Careful Spenders':    ("Moderate income, conservative spending, mid-age.",
                            "Instalment offers, trust-building campaigns, reviews."),
    'Young Explorers':     ("Young, varied income, high spending potential.",
                            "Trend-driven ads, social media, BNPL options."),
    'Affluent Moderates':  ("High income, restrained spending, mature.",
                            "Premium product lines, exclusive memberships, events."),
    'High-Value Targets':  ("High income AND high spending — most profitable.",
                            "VIP programs, personalised luxury offers, retention."),
}

for idx, row in profile.iterrows():
    seg = row['Segment']
    profile_txt, action = marketing_actions.get(seg, ("", ""))
    report_lines.append(f"── Segment: {seg} (Cluster {idx}) ──")
    report_lines.append(f"   Count          : {int(row['Count'])} customers")
    report_lines.append(f"   Avg Age        : {row['Age_mean']:.1f} yrs")
    report_lines.append(f"   Avg Income     : ${row['Income_mean']:.1f}k")
    report_lines.append(f"   Avg Spending   : {row['Spending_mean']:.1f}/100")
    report_lines.append(f"   Profile        : {profile_txt}")
    report_lines.append(f"   Marketing Action: {action}")
    report_lines.append("")

report_text = "\n".join(report_lines)
print("\n" + report_text)

with open('/mnt/user-data/outputs/segment_report.txt', 'w') as f:
    f.write(report_text)
print("✓ Segment report saved to segment_report.txt")
